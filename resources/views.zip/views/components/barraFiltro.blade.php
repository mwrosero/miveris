{{-- Filtro para pendientes --}}
<div class="col-auto bg-white p-2">
    <button class="btn btn-sm btn-outline-primary-veris ms-2 px-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#filtroTratamientos" aria-controls="filtroTratamientos" ><img src="{{asset('assets/img/svg/filtro.svg')}}" class="me-1" alt="filtro"> 
        <p class="fs--1 line-height-16 fw-normal mb-0" id="nombreFiltro"></p>
    </button>
</div>


